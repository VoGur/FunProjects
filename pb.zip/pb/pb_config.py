import logging.config
import logging.handlers
import queue


#Package config parameters should go here
STOP_WAIT_SECS = 5.0            #group manager will wait for worker processes when stop
NUM_TRIES_TO_TERM = 3           #number of attempts to terminate worker process
STARTUP_WAIT_SECS = 5.0         #worker process startup timeout
SHUTDOWN_WAIT_SECS = 5.0        #worker process shutdown timeout
DEFAULT_POLLING_TIMEOUT = 0.02  #queue polling timeout
MAX_NUM_TERM_SIGNAL_CALLED = 3  #max number of term signals to react, throw exception after

#Will be using RotatingFileHandler, to support rotation of disk log files, currently 2 Mb per log file set
LOG_FILENAME = 'c:/Dima/Solace/pg.log'
LOG_SIZE = 2*1024*1024 #2Mb i.e 2097152
LOGS_FILE_NUM = 100

'''
The logging "QueueHandler with QueueListener" solution used to
share the queue where Handler adds the messages to the queueu while Listener
pulls the messages and forwarding to destination handlers

        "queue_listener": {
            "class": "examples.QueueListenerHandler",
            "handlers": [
                "cfg://handlers.console",
                "cfg://handlers.file"
            ]
        }
'''

'''
Log handlers:
    console
    log_file_handler
SPECIAL NOTE:
    "queue_listener" is a combination of QueueHandler/QueueListener 

Use "pb" is main logger which will produce rotating logs


'''
#update as needed
LOGGING_CONFIG = {
	"version": 1,
	"disable_existing_loggers": False,
	"formatters": {
		"simple": {
			"format": "%(asctime)s [%(levelname)s] %(name)s %(message)s"
		},
		"detailed": {
			"format": "%(asctime)s P%(process)-5d T%(thread)-5d %(levelname)8s [%(filename)s:%(lineno)s] %(name)s.%(funcName)s() %(message)s"
		}
	},
	"handlers": {
		"console": {
			"class": "logging.StreamHandler",
			"level": "DEBUG",
			"formatter": "detailed",
            "stream": "ext://sys.stdout"
		},
		"log_file_handler": {
			"class": "logging.handlers.RotatingFileHandler",
			"level": "DEBUG",
			"formatter": "detailed",
			"filename": "c:/Dima/Solace/pg.log",
			"maxBytes": 2097152,
			"backupCount": 100
		}
	},
	"loggers": {
		"pb": {
			"level": "DEBUG",
			"handlers": [
				"console",
				"log_file_handler"
			],
			"propagate": False
		}
	},
	"root": {
		"level": "DEBUG",
		"handlers": [
			"console",
			"log_file_handler"
		]
	}
}


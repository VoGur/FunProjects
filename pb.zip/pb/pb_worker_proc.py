import multiprocessing as mp
import time
import logging
import pb_config as cfg

'''
"WorkerProc" controls "Worker" class functionality, if you will it is worker handler which will control the worker lifecycle
Worker class is a class which derrived from "Worker" 
'''
MOD_LOG_NAME = "pb.wrkr_proc"
logger = logging.getLogger(MOD_LOG_NAME)

'''
Mandatory parameters when instantiate a worker process 
name, 
startup_event, 
shutdown_event, 
log_q,                  logger
event_q,                events
msg_q                   dedicated messages for the process 
Optional: *args         pass whatever needed
 
'''

def proc_worker_wrapper(proc_worker_class, name, startup_evt, shutdown_evt, log_q, event_q, msg_q, *args):
    proc_worker = proc_worker_class(name, startup_evt, shutdown_evt, log_q, event_q, msg_q, *args)
    return proc_worker.run()


# "WorkerProc" instantiates and controls a Worker class
class WorkerProc:

    def __init__(self, name, worker_class, startup_event, shutdown_event, log_q, event_q, msg_q, *args):

        self.name = name
        self.shutdown_event = shutdown_event
        self.startup_event = startup_event
        self.proc = mp.Process(target=proc_worker_wrapper,
                               args=(worker_class, name, self.startup_event, shutdown_event, log_q, event_q, msg_q, *args))
        self.proc.start()
        started = self.startup_event.wait(timeout=cfg.STARTUP_WAIT_SECS)
        if not started:
            self.terminate()
            raise RuntimeError(f"Failed to start instance of {worker_class} named {name} after {cfg.STARTUP_WAIT_SECS} sec")
        else:
            logger.debug(f"{worker_class} named {name} proc {self.proc.pid}")

    #By default the parent will not exit until all of the children have exited
    #After process shutdown ebvent issued we wait for a child process to exit within SHUTDOWN_WAIT_SECS
    #and call terminate() if it didn't
    def full_stop(self, wait_time=cfg.SHUTDOWN_WAIT_SECS):
        logger.debug(f"Will attempt to stop {self.proc.pid} {self.name}")
        self.shutdown_event.set()
        self.proc.join(wait_time)
        logger.debug(f"Proc status: {self.proc} {self.proc.is_alive()}")
        if self.proc.is_alive():
            self.terminate()

    #Calling terminate() on a process object kills the child process.
    def terminate(self):
        logger.debug(
            f"Will terminate {self.proc.pid} {self.name}")
        tries = cfg.NUM_TRIES_TO_TERM
        while tries and self.proc.is_alive():
            self.proc.terminate()
            time.sleep(0.01)
            tries -= 1

        if self.proc.is_alive():
            logger.debug(
                f"Wrkr proc {self.proc.pid} {self.name} is alive after {cfg.NUM_TRIES_TO_TERM} term attempt(s)")
            return False
        else:
            logger.debug(
                f"Wrk proc {self.proc.pid} {self.name} terminated after {cfg.NUM_TRIES_TO_TERM - tries +1} attempt(s)")
            return True

    def __enter__(self):
        return self


    def __exit__(self, exc_type, exc_val, exc_tb):
        logger.log(logging.DEBUG, f"Wrkr {self} exiting")
        self.full_stop()
        return not exc_type


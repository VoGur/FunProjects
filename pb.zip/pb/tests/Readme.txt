Depend on which functionality you would like to test:

------------------------ Loging ----------------------------
test_logger.py				basic logger format testing
test_queue_logger.py		a number of proceeses log messages into Python multiporcessing.
                            Queue from where logger process reads and dumps meessages into a log file(plus Solace)
-------------------- Basic components -----------------------------
test_components.py          test process group componenets basic functionality
------------------------ Group -----------------------------
test_group_CtrlC.py			to test group, events, logging, signal handlers and Ctrl^C functionality
test_group.py	            listening to TCP/IP and dispatching messages to the processes as needed .
                            Use test_TCP_client.py to send a message
--------------------- Full version ---------------------------


import sys
sys.path.insert(0, '../')
import pb_config as cfg
import logging.config
import logging
import pb_logger as pblog
import getopt


#To test and demonstarte the basic logging options :format, file name logging and exception handling


def log_levels():
    logger.debug('Test debug message')
    logger.info('Test info message')
    logger.warning('Test warn message')
    logger.error('Test error message')
    logger.critical('Test critical message')

def name_shaddowing(logger):
    logger = logging.getLogger('shaddowing')
    logging.config.dictConfig(cfg.LOGGING_CONFIG)
    log_levels()

#Example of configuration using JSON obj ( preferable) and manual
if __name__ == '__main__':
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'd:', ['dict'])


        # for now just check if a paramater specfied
        if len(opts) == 0:

            #getting paramaters from JSON obj , by default
            # pb logger here
            logger = pblog.get_logger('pb')
            logger.debug('Configuration set based on JSON from config.py - logging.config.dictConfig(cfg.LOGGING_CONFIG)')

            print(
                '---------------------------------TEST 1. USE JSON configuration -------------------------------------------')
            print('In addition to console log entries, see log file entries in "detailed" format in file:')
            print(cfg.LOG_FILENAME)

            print(
                '---- CASE 1.1: DEFAULT LOGGER SETTINGS - LOGGER NAME original name pb -------------------------------------')
            log_levels()

            print(
                '---- CASE 1.2: LOGGER NAME SHADDOWING, ATTEMPTING TO CHANGE LOGGER NAME IN A FUNCTION:  no effect ---------')
            name_shaddowing(logger)

            # if new logger name derrives from logger name configured i.e pb
            # if we modify it as in the case the configuration will be preserved i.e pattern "pb."
            print(
                '---- CASE 1.3: LOGGER NAME CHANGING: pb-> pb.aa, pb loger settings remain ---------------------------------')
            logger = pblog.get_logger('pb.aa')
            log_levels()

            # if new logger name is not derrived from the original logger name i.e "aa.pb"
            # root configuration will be used
            print(
                '-------CASE 1.4: LOGGER NAME CHANGING: name changed and root settings used --------------------------------')
            logger = pblog.get_logger('aa.pb')
            log_levels()

            print(
                '-------CASE 1.5: TRIGGER EXCEPTION ON PURPOSE: log details --------------------------------')
            logger = pblog.get_logger('zz')
            #logging.config.dictConfig(cfg.LOGGING_CONFIG)
            logger.failure('Test critical message')     # use wrong parameter
        else:

            logger = pblog.get_logger('pb', False)
            logger.debug('Configuration set using Logging config functions')

            print(
                '------------------------------------TEST2. USE pb logger functions ----------------------------------------')
            print('In addition to console log entries, see log file entries in "detailed" format in file:')

            print(
                '---- CASE 2.1: DEFAULT LOGGER SETTINGS - LOGGER NAME original name pb -------------------------------------')
            log_levels()

            print(
                '---- CASE 2.2: LOGGER NAME SHADDOWING, ATTEMPTING TO CHANGE LOGGER NAME IN A FUNCTION:  no effect ---------')
            name_shaddowing(logger)

            # if new logger name derrives from logger name configured i.e pb
            # if we modify it as in the case the configuration will be preserved i.e pattern "pb."
            print(
                '---- CASE 2.3: LOGGER NAME CHANGING: pb-> pb.aa, pb loger settings remain ---------------------------------')
            logger = pblog.get_logger('pb.aa', False)
            #logging.config.dictConfig(cfg.LOGGING_CONFIG)
            log_levels()

            # if new logger name is not derrived from the original logger name i.e "aa.pb"
            # root configuration will be used
            print(
                '-------CASE 2.4: LOGGER NAME CHANGING: name changed and root settings used --------------------------------')
            logger = pblog.get_logger('aa.pb', False)
            #logging.config.dictConfig(cfg.LOGGING_CONFIG)
            log_levels()

            print(
                '-------CASE 2.5: TRIGGER EXCEPTION ON PURPOSE: log details ------------------------------------------------')
            logger = pblog.get_logger('zz',False)
            logger.failure('Test critical message')     # use wrong parameter

    except BaseException as exc:
        logger.error('Logging exception', exc_info = True)
        sys.exit(2)

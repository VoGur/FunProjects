import logging
import multiprocessing as mp
import os
import signal
import sys
sys.path.insert(0, '../')
import pb_config as cfg
import time
from pb_sig_handler import (
    init_signal,        #set handlers for SIGINT & SIGTERM (CTRL^C)
    default_signal_handler,
    ShutdownSignalObject,
    TerminateInterrupt
)
from pb_worker_proc import (
    proc_worker_wrapper,
    WorkerProc
)
from pb_worker import (
    Worker,
    TimerWorker,
)
from pb_group_mngr import GroupManager
from pb_queue import (
    PBqueue,
)

from pb_worker import(
    Worker,
    QueueWorker
)


import pb_logger as pblog
logger = pblog.get_logger('pb')


#you will need to deploy
import pytest



def _sleep_secs(max_sleep, end_time=99999999999.9):
    #Calculate time left to sleep, no less than 0
    return max(0.0, min(end_time - time.time(), max_sleep))

def test_pbqueue_get():
    Q = PBqueue("Test")

    item = Q.safe_get(None)
    assert item is None

    Q.put("ITEM1")
    Q.put("ITEM2")

    assert Q.safe_get(0.02) == "ITEM1"
    assert Q.safe_get(0.02) == "ITEM2"
    assert Q.safe_get(0.02) is None
    assert Q.safe_get(None) is None

    num_left = Q.safe_close()
    assert num_left == 0


def test_queue_put():
    Q = PBqueue("Test",2)
    assert Q.safe_put("ITEM1")
    assert Q.safe_put("ITEM2")
    assert not Q.safe_put("ITEM3")

    num_left = Q.safe_close()
    assert num_left == 2


def test_flush_queue():
    Q = PBqueue("Test")

    items = list(Q.flush())
    assert items == []

    expected = [f"ITEM{idx}" for idx in range(10)]
    for item in expected:
        Q.put(item)

    items = list(Q.flush())
    assert items == expected

    num_left = Q.safe_close()
    assert num_left == 0


def test_sleep_secs():
    assert _sleep_secs(5.0, time.time() - 1.0) == 0.0
    assert _sleep_secs(1.0, time.time() + 5.0) == 1.0

    end_time = time.time() + 4.0
    got = _sleep_secs(5.0, end_time)
    assert got <= 4.0
    assert got >= 3.7


def test_signal_handling():
    pid = os.getpid()
    evt = mp.Event()
    so = ShutdownSignalObject(evt)
    init_signal(signal.SIGINT, so, KeyboardInterrupt, default_signal_handler)
    assert not so.shutdown_event.is_set()
    assert so.terminate_called == 0

    os.kill(pid, signal.SIGINT)
    assert so.terminate_called == 1
    assert so.shutdown_event.is_set()

    os.kill(pid, signal.SIGINT)
    assert so.terminate_called == 2
    assert so.shutdown_event.is_set()

    with pytest.raises(KeyboardInterrupt):
        os.kill(pid, signal.SIGINT)

    assert so.terminate_called == 3
    assert so.shutdown_event.is_set()


def test_proc_worker_bad_args():
    with pytest.raises(ValueError):
        Worker("WorkerTEST", 1, 2, 3, "ARG1", "ARG2")


class WorkerTest(Worker):
    def init_args(self, args):
        self.args = args

    def main_func(self):
        logger.info(f"MAIN_FUNC: {self.args}")
        self.shutdown_event.set()


def test_proc_worker_good_args():
    pw = WorkerTest("WorkerTEST", 1, 2, 3, "ARG1", "ARG2")
    assert pw.args == ('ARG1', 'ARG2')


def test_proc_worker_init_signals():
    pid = os.getpid()
    evt = mp.Event()
    #Parameters: name, startup_event, shutdown_event, log_q, event_q, msg_q, *argc
    pw = Worker("WorkerTEST",evt, evt, None, None, None)
    so = pw.init_signals()

    assert not so.shutdown_event.is_set()
    assert so.terminate_called == 0

    os.kill(pid, signal.SIGINT)
    assert so.terminate_called == 1
    assert so.shutdown_event.is_set()

    os.kill(pid, signal.SIGINT)
    assert so.terminate_called == 2
    assert so.shutdown_event.is_set()

    with pytest.raises(KeyboardInterrupt):
        os.kill(pid, signal.SIGINT)

    assert so.terminate_called == 3
    assert so.shutdown_event.is_set()


def test_proc_worker_no_main_func(caplog):
    startup_evt = mp.Event()
    shutdown_evt = mp.Event()
    q = PBqueue("QueueTest")

    try:
        caplog.set_level(logging.INFO)
        #Paramters: name, worker_class, startup_event, shutdown_event, log_q, event_q, msg_q, *args
        pw = Worker("TEST", startup_evt, shutdown_evt, q, None, None)
        with pytest.raises(NotImplementedError):
            pw.main_func()

    finally:
        q.safe_close()


def test_proc_worker_run(caplog):
    startup_evt = mp.Event()
    shutdown_evt = mp.Event()
    q = PBqueue("Test")

    caplog.set_level(logging.INFO)
    pw = Worker("WorkerTEST", startup_evt, shutdown_evt, q, None, None, "ARG1", "ARG2")
    assert not startup_evt.is_set()
    assert not shutdown_evt.is_set()

    pw.run()

    assert startup_evt.is_set()
    assert shutdown_evt.is_set()
    item = q.safe_get()
    assert item
    assert item.msg_src == "TEST"
    assert item.msg_type == "SHUTDOWN"
    assert item.msg == "Normal"
    assert f"MAIN_FUNC: ('ARG1', 'ARG2')" in caplog.text


#proc_worker_class, name, startup_evt, shutdown_evt, event_q, log_q, msg_q, *args
def _proc_worker_wrapper_helper(caplog, worker_class, args=None, expect_shutdown_evt=True, alarm_secs=1.0):
    startup_evt = mp.Event()
    shutdown_evt = mp.Event()
    event_q = PBqueue("Test")
    if args is None:
        args = ()

    def alarm_handler(signal_num, current_stack_frame):
        shutdown_evt.set()

    if alarm_secs:
        signal.signal(signal.SIGALRM, alarm_handler)
        signal.setitimer(signal.ITIMER_REAL, alarm_secs)
    caplog.set_level(logging.DEBUG)
    exitcode = proc_worker_wrapper(worker_class, "TEST", startup_evt, shutdown_evt, event_q, *args)
    assert startup_evt.is_set()
    assert shutdown_evt.is_set() == expect_shutdown_evt
    items = list(event_q.flush())
    assert items
    last_item = items[-1]
    assert last_item.msg_src == "TEST"
    assert last_item.msg_type == "SHUTDOWN"
    assert last_item.msg == "Normal"
    assert exitcode == 0

    return items[:-1]


def test_proc_worker_wrapper(caplog):
    items = _proc_worker_wrapper_helper(caplog, WorkerTest, ("ARG1", "ARG2"))
    assert not items
    assert f"MAIN_FUNC: ('ARG1', 'ARG2')" in caplog.text


def test_proc_worker_exception(caplog):
    class ProcWorkerException(WorkerProc):
        def main_func(self):
            raise NameError("Because this doesn't happen often")

    startup_evt = mp.Event()
    shutdown_evt = mp.Event()
    event_q = PBqueue("Test")

    caplog.set_level(logging.INFO)
    with pytest.raises(SystemExit):
        proc_worker_wrapper(ProcWorkerException, "TEST", startup_evt, shutdown_evt, event_q)
    assert startup_evt.is_set()
    assert not shutdown_evt.is_set()
    item = event_q.safe_get()
    assert item
    assert item.msg_src == "TEST"
    assert item.msg_type == "FATAL"
    assert item.msg == "Because this doesn't happen often"

    assert f"Exception Shutdown" in caplog.text


class TimerProcWorkerTest(TimerWorker):
    INTERVAL_SECS = 0.01
    times_called = 0

    def main_func(self):
        self.times_called += 1
        self.event_q.put(f"TIMER {self.times_called} [{time.time()}]")
        if self.times_called >= 4:
            self.shutdown_event.set()


def test_timer_proc_worker(caplog):
    items = _proc_worker_wrapper_helper(caplog, TimerProcWorkerTest)
    assert len(items) == 4
    for idx, item in enumerate(items[:-1]):
        assert item.startswith(f'TIMER {idx + 1} [')


class QueueWorkerTest(QueueWorker):
    def main_func(self, item):
        self.event_q.put(f'DONE {item}')


def test_queue_proc_worker(caplog):
    work_q = PBqueue("Test")
    work_q.put(1)
    work_q.put(2)
    work_q.put(3)
    work_q.put(4)
    work_q.put("END")
    work_q.put(5)

    items = _proc_worker_wrapper_helper(caplog, QueueWorkerTest, args=(work_q,), expect_shutdown_evt=False)
    assert len(items) == 4
    assert items == [f'DONE {idx + 1}' for idx in range(4)]


def test_proc_start_hangs(caplog):
    class StartHangWorker(WorkerProc):
        def startup(self):
            while True:
                time.sleep(1.0)

    shutdown_evt = mp.Event()
    event_q = PBqueue("Test")
    caplog.set_level(logging.INFO)
    cfg.STARTUP_WAIT_SECS = 0.2
    try:
        with pytest.raises(RuntimeError):
            WorkerProc("TEST", StartHangWorker, shutdown_evt, event_q, None ,None)
    finally:
        cfg.STARTUP_WAIT_SECS = 3.0


def test_proc_full_stop(caplog):
    shutdown_evt = mp.Event()
    event_q = PBqueue("Test")
    caplog.set_level(logging.INFO)
    proc = WorkerProc("TEST", TimerProcWorkerTest, shutdown_evt, event_q)

    for idx in range(4):
        item = event_q.safe_get(1.0)
        assert item, f"idx: {idx}"
        assert item.startswith(f'TIMER {idx + 1} [')

    item = event_q.safe_get(1.0)
    assert item.msg_src == "TEST"
    assert item.msg_type == "SHUTDOWN"
    assert item.msg == "Normal"

    proc.full_stop(wait_time=0.5)

    assert not proc.proc.is_alive()


def test_proc_full_stop_need_terminate(caplog):
    class NeedTerminateWorker(WorkerProc):
        def main_loop(self):
            while True:
                time.sleep(1.0)

    shutdown_evt = mp.Event()
    event_q = PBqueue("Test")
    caplog.set_level(logging.INFO)
    proc = WorkerProc("TEST", NeedTerminateWorker, shutdown_evt, event_q)
    proc.full_stop(wait_time=0.1)


def test_main_context_stop_queues():
    with GroupManager() as grp:
        q1 = grp.PBqueue("Test")
        q1.put("SOMETHING 1")
        q2 = grp.PBQueue()
        q2.put("SOMETHING 2")

    # -- 3 == the 2 queued items in this test, and the END event
    assert grp._stopped_queues_result == 3


def _test_stop_procs(cap_log, proc_name, worker_class):
    cap_log.set_level(logging.DEBUG)
    with GroupManager() as grp:
        grp.STOP_WAIT_SECS = 0.1
        grp.create_worker_proc(proc_name, worker_class)
        time.sleep(0.05)

    for proc in grp.procs:
        proc.terminate()
    return grp._stopped_procs_result, len(grp.procs)


def test_main_context_exception():
    with pytest.raises(ValueError):
        with GroupManager()():
            raise ValueError("Testing a value Error")


def test_main_context_stop_procs_clean(caplog):
    class CleanProcWorker(WorkerProc):
        def main_func(self):
            time.sleep(0.001)
            return

    (num_failed, num_terminated), num_still_running = _test_stop_procs(caplog, "CLEAN", CleanProcWorker)
    assert num_failed == 0
    assert num_terminated == 0
    assert num_still_running == 0


def test_main_context_stop_procs_fail(caplog):
    class FailProcWorker(WorkerProc):
        def main_func(self):
            logger.debug(f"main_func called")
            time.sleep(0.001)
            logger.debug(f"main_func raising")
            raise ValueError("main func value error")

    caplog.set_level(logging.DEBUG)
    (num_failed, num_terminated), num_still_running = _test_stop_procs(caplog, "FAIL", FailProcWorker)
    assert num_failed == 1
    assert num_terminated == 0
    assert num_still_running == 0


def _test_main_context_hang(cap_log, is_hard):
    class HangingProcWorker(WorkerProc):
        def main_loop(self):
            MAX_TERMINATES = 2 if is_hard else 1
            num_terminates = 0
            while num_terminates < MAX_TERMINATES:
                try:
                    while True:
                        time.sleep(5.0)
                except TerminateInterrupt:
                    num_terminates += 1

    return _test_stop_procs(cap_log, "HANG", HangingProcWorker)


def test_main_context_stop_procs_hung_soft(caplog):
    (num_failed, num_terminated), num_still_running = _test_main_context_hang(caplog, is_hard=False)
    assert num_failed == 0
    assert num_terminated == 1
    assert num_still_running == 0


def test_main_context_stop_procs_hung_hard(caplog):
    (num_failed, num_terminated), num_still_running = _test_main_context_hang(caplog, is_hard=True)
    assert num_failed == 0
    assert num_terminated == 0
    assert num_still_running == 1
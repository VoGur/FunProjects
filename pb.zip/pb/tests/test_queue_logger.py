import sys
sys.path.insert(0, '../')
import logging
import multiprocessing
from random import choice, random
import time
import pb_logger as pblog

#To test and demonstarte child processes logging to queue and parent getting msgs from there and logging to a log file from there
#You can iterrupt the execution using Ctr-C

#pb logger here
#logger = logging.getLogger('pb')
#logger.setLevel(logging.DEBUG)

#to demonstarte the options print() used to just for separators
LEVELS = [logging.DEBUG, logging.INFO, logging.WARNING,
          logging.ERROR, logging.CRITICAL]


MESSAGES = [
    'Random message A',
    'Random message B',
    'Random message C',
    'Random message D',
    'Random message E',
    'Random message F',
]


#set up logger which will be listening to the queue and dump logs to a file
def worker_process(queue, log_configurer):
    logger = log_configurer(queue)
    name = multiprocessing.current_process().name
    logger.info(f'Worker {name} started')

    try:
        for i in range(10):
            time.sleep(random())
            #logger = logging.getLogger(choice(LOGGERS))
            level = choice(LEVELS)
            message = choice(MESSAGES) + " from " + name
            logger.log(level, message)
    except BaseException as exc:
        if type(exc) in (KeyboardInterrupt, InterruptedError):
            logger.debug(f"Worker terminated by signal")
            exit(1)
        else:
            import sys, traceback
            print('An exception logging messages from log queue:', file=sys.stderr)
            traceback.print_exc(file=sys.stderr)

    logger.info(f'Worker {name} finished')



def listener_process(queue,log_configurer):
        logger = log_configurer()
        logger.info('Listener started listening to the log queue')

        while True:
            try:
                record = queue.get()
                if record is None:  # We send this as a sentinel to tell the listener to quit.
                    logger.debug(f"No more log messages in the log queue - will exit listener")
                    break
                else:
                    logger.debug(f"Listener pulled message from log queue : {record}")
                #logger = logging.getLogger(record.name)
                logger.handle(record)  #logs queue entry depend on log_configurer() setup
                #logger.info(f'Got {record.msg}')

            except BaseException as exc:
                if type(exc) in (KeyboardInterrupt, InterruptedError):
                    logger.debug(f"Listener terminated by signal")
                    exit(1)
                else:
                    import sys, traceback
                    print('An exception getting messages from log queue:', file=sys.stderr)
                    traceback.print_exc(file=sys.stderr)

        logger.info(f'Listener exiting')



def main():

    logger = pblog.get_grp_logger()
    logger.debug('Group processing begin')
    try:
        #Start process which will be listening to log messages from worker processes
        queue = multiprocessing.Queue(-1)
        listener = multiprocessing.Process(target=listener_process,
                                           args=(queue, pblog.listener_log_configurer))
        listener.start()

        workers = []
        for i in range(10):
            worker = multiprocessing.Process(target=worker_process,
                                             args=(queue, pblog.worker_log_configurer))
            workers.append(worker)
            worker.start()

        for w in workers:
            w.join()

        #insert empty message to finish workers
        queue.put_nowait(None)
        listener.join()
    except BaseException as exc:
        if type(exc) in (KeyboardInterrupt, InterruptedError):
            logger.debug(f"Terminated by signal")
            exit(1)
        else:
            import sys, traceback
            print('An exception:', file=sys.stderr)
            traceback.print_exc(file=sys.stderr)


if __name__ == '__main__':
        main()

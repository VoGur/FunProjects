import sys
sys.path.insert(0, '../')
import pb_logger as pblog
from pb_group_mngr import GroupManager

from workers.pb_queue_worker import(
    QueueWorker
)
from pb_sig_handler import (
    TerminateInterrupt
)

#Test processes started and controlled by group manger,
#can be interrupted by Ctrl-C
#see the logs for all the activities which occur during the run
#https://stackoverflow.com/questions/14136195/what-is-the-proper-way-to-handle-in-python-ioerror-errno-4-interrupted-syst
#Catching  [Errno 4] Interrupted function call


def main(die_in_secs):
    logger = pblog.get_grp_logger()
    logger.debug('Started manager')

    args = None
    with GroupManager() as mngr:
        #Start workers
        mngr.create_worker_proc("QueueWrkProc1", QueueWorker, args)
        mngr.create_worker_proc("QueueWrkProc2", QueueWorker, args)
        mngr.create_worker_proc("QueueWrkProc3", QueueWorker, args)


        #Processing events untill get shutdown
        while not mngr.shutdown_event.is_set():
            try:
                if mngr.event_queue.is_on():
                    event = mngr.event_queue.safe_get()
                    if not event:
                        continue
            except BaseException as exc:
                #we dont need stack for the exceptions we know we triggered
                if type(exc) in (TerminateInterrupt, KeyboardInterrupt, InterruptedError):
                    logger.debug(f"Terminated by signal")
                else:
                    logger.debug(f"Abornmal exit:{exc}", exc_info=True )

if __name__ == "__main__":
    main(1)
	
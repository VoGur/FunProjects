import sys
sys.path.insert(0, '../')
import pb_logger as pblog
from pb_group_mngr import GroupManager

from workers.pb_queue_worker import(
    QueueWorker
)
from workers.pb_network_listener import(
    NetworkListenerWorker
)
from pb_sig_handler import (
    TerminateInterrupt
)

#Test processes started and controlled by group manger - use to check Cntrl-^C,
#can be interrupted by Ctrl-^C
#see the logs for all the activities which occur during the run
#https://stackoverflow.com/questions/14136195/what-is-the-proper-way-to-handle-in-python-ioerror-errno-4-interrupted-syst
#Catching  [Errno 4] Interrupted function call



def main(die_in_secs):
    logger = pblog.get_grp_logger()
    logger.debug('Started manager')

    args = None
    with GroupManager() as mngr:
        #Start workers
        mngr.create_worker_proc("NetworkListener",NetworkListenerWorker,args)
        mngr.create_worker_proc("QueueWrkProc1", QueueWorker, args)
        #mngr.create_worker_proc("QueueWrkProc1", QueueWorker, args)
        #mngr.create_worker_proc("QueueWrkProc2", QueueWorker, args)
        #mngr.create_worker_proc("QueueWrkProc3", QueueWorker, args)


        #Processing events untill get shutdown
        while not mngr.shutdown_event.is_set():
            try:
                if mngr.event_queue.is_on():
                    item = mngr.event_queue.safe_get()
                    # no events - there is nothing to do , keep looping
                    # otherwise check what we can do
                    if item:
                        logger.debug(f"Got event: {item}")
                        if item.msg_type == "END":
                            logger.debug(f"Exiting: {item}")
                            break;
                        elif item.msg_type == "REQUEST":
                            logger.debug(f"Processing request: {item}")
                        else:
                            logger.debug(f"Unknown msg type : {item}")

            except BaseException as exc:
                #we dont need stack for the exceptions we know we triggered
                if type(exc) in (TerminateInterrupt, KeyboardInterrupt, InterruptedError):
                    logger.debug(f"Terminated by signal")
                else:
                    logger.debug(f"Abornmal exit:{exc}", exc_info=True )

if __name__ == "__main__":
    main(1)
	
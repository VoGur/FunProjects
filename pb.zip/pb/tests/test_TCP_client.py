import socket
import sys
import time


#To connect to worker listening to TCP/IP channel . Hardcopded PORT should be used on the same host
#by NetworkListenerWorker to send a message
PORT = 9876
HOST = 'localhost'
WAIT_TIME = 3
NTEST=2

def send_request(*args):

    ADDRESS = (HOST, PORT)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(ADDRESS)

    print(f"TCP/IP CLIENT: Connected to {HOST}:{PORT}")
    request = f"{'::'.join(args)}"
    print("TCP/IP CLIENT: Sending  : ", request)
    sock.send(request.encode("utf-8"))

    reply = sock.recv(1500).decode()
    print("TCP/IP CLIENT: Received : ", reply)

    print("TCP/IP CLIENT: Closing socket")
    sock.close()


print(f"TCP/IP CLIENT: Started")
print(f"Make sure you have started PB group test_group.py and you have NetworkListenerWorker running in the group listening on port {PORT}")
arguments = len(sys.argv) - 1
print (f"Detected {arguments} arguments {sys.argv[1:]}")
if arguments == 0 or (sys.argv[1] and sys.argv[1] == "AUTO"):
    print(f"AUTO mode : will send {NTEST} test 'REQUEST' followed by 'END' messages")

    for i in range(NTEST):
        print(f"TCP/IP CLIENT: Waiting {WAIT_TIME} sec and sending TEST")
        time.sleep(WAIT_TIME)
        send_request(f"REQUEST {i + 1}")
    print(f"TCP/IP CLIENT: Waiting {WAIT_TIME} sec and sending END")
    time.sleep(5)
    send_request(f"END {NTEST + 1}")
elif  arguments == 1 and sys.argv[1] and sys.argv[1] != "AUTO":
    print(f"TCP/IP CLIENT: sending {sys.argv[1]} and waiting for {WAIT_TIME} sec")
    send_request(sys.argv[1:])
    time.sleep(WAIT_TIME)
else :
    print(f"TCP/IP CLIENT: provided more parameters than expected")
print(f"TCP/IP CLIENT: Exited")
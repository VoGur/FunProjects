import logging
import logging.config
import logging.handlers
import pb_config as cfg
from datetime import datetime
from pb_worker import Worker
from pb_sig_handler import (
    TerminateInterrupt
)

'''
Logging name hierarhy setup:
https://www.toptal.com/python/in-depth-python-logging
https://stackoverflow.com/questions/50714316/how-to-use-logging-getlogger-name-in-multiple-modules
specifics:
Logging to a single file from multiple processes is not supported, because there is no standard way
to serialize access to a single file across multiple processes in Python.Options:
https://stackoverflow.com/questions/641420/how-should-i-log-while-using-multiprocessing-in-python
https://docs.python.org/3/howto/logging-cookbook.html#logging-to-a-single-file-from-multiple-processes
Will be use a Queue and a QueueHandler to send all logging events to one of the processes in your multi-process application
Check dictionary style logger configuration is in 'config.py '
logger = logging.getLogger('pb')
Set up your logger by loading dictionary from JSON setup:
logging.config.dictConfig(cfg.LOGGING_CONFIG)
or by explicitely adding handlers
add_console_handler()
add_rotating_files_handler()
# ...

'''
MOD_LOG_NAME = "pb.logger"
logger = logging.getLogger(MOD_LOG_NAME)

#Optional to modify the way how the rotating file will be named
def rotating_log_file_name(file_name):
    #base_name, ext, cntr = file_name.split(".")
    #rearrange default logname.log.1 and add timestamp YYYY-MM-DD-HHMMSS
    tm= datetime.now().strftime("%d%m%Y_%H:%M")
    return file_name + f".{tm}"

#Handler to log messages to console
def add_console_handler():
    cons_log_formatter = logging.Formatter("%(asctime)s P%(process)-5d T%(thread)-5d %(levelname)8s [%(filename)s:%(lineno)s] %(name)s.%(funcName)s() %(message)s")
    #logging.Formatter("%(asctime)s [%(levelname)s] %(name)s %(message)s")
    c_handler = logging.StreamHandler()
    c_handler.setLevel(logging.DEBUG)
    c_handler.setFormatter(cons_log_formatter)
    return c_handler

#Handler to log messages to rotating file
#Special note: additionaly rotating log file name can be modified
def add_rotating_files_handler():
    rt_f_log_formatter = logging.Formatter("%(asctime)s P%(process)-5d T%(thread)-5d %(levelname)8s [%(filename)s:%(lineno)s] %(name)s.%(funcName)s() %(message)s")
    #Rotating file logs handler
    rt_f_handler = logging.handlers.RotatingFileHandler(cfg.LOG_FILENAME, maxBytes=cfg.LOG_SIZE,backupCount=cfg.LOGS_FILE_NUM)
    rt_f_handler.setLevel(logging.DEBUG)
    rt_f_handler.setFormatter(rt_f_log_formatter)
    rt_f_handler.namer = rotating_log_file_name(cfg.LOG_FILENAME)
    return rt_f_handler

'''
workers (child processes) will be sharing "multiprocesing.queue" with parent and log messages
to the queue from where parent process will pick up them and add to it's own log
Special note:
format can be ignored because all the child process logging details will be retrieved from the messages
inserted into the queue and shown in the format of the parent proces logger
'''
def add_queue_handler(queue):
    #q_formatter = logging.Formatter(
    #    "%(asctime)s P%(process)-5d T%(thread)-5d %(levelname)8s [%(filename)s:%(lineno)s] %(name)s.%(funcName)s() %(message)s")
    #q_handler.setFormatter(q_formatter)

    q_handler = logging.handlers.QueueHandler(queue)
    q_handler.setLevel(logging.DEBUG)
    return q_handler

#get logger with desired name
# logger.addHandler(add_queue_handler())   when needed we can always add queue logger
def get_logger(logger_name, dict = False):
    logger = logging.getLogger(logger_name)
    if dict:
        logging.config.dictConfig(cfg.LOGGING_CONFIG)
    else:
        logger.setLevel(logging.DEBUG)
        logger.addHandler(add_console_handler())
        logger.addHandler(add_rotating_files_handler())
        # with this pattern, it's rarely necessary to propagate the error up to parent
        logger.propagate = False
    return logger


def get_grp_logger(logger_name = 'pb', dict = False):
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(add_console_handler())
    logger.addHandler(add_rotating_files_handler())
    return logger


#retrieve logs from currently queue and dump to log file and console
def listener_log_configurer(logger_name = 'pb'):
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(add_rotating_files_handler())
    logger.addHandler(add_console_handler())
    return logger

#set queue logger
def worker_log_configurer(queue, logger_name = 'pb' ):
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(add_queue_handler(queue))
    return logger


'''
Dedicated LogListener mandatory parameters:
name
startup_event
shutdown_event
event_q                           
log_q
Additional arguments can be passed as args 
'''
class LogListener(Worker):
    def __init__(self,name, startup_event, shutdown_event, log_q, event_q, msg_q, *args):
        super(LogListener, self).__init__(name, startup_event, shutdown_event, log_q, event_q, msg_q, *args)
        #keep configurer
        logger = listener_log_configurer(MOD_LOG_NAME)

    def init_args(self, args):
        logger.debug(f'Listener started listening to the log queue')
        logger.debug(f"QueueWorker init_args : {args}")


    def main_loop(self):
        logger.debug(f"{self.name} main_loop start")
        while not self.shutdown_event.is_set():
            try:
                #logger.debug(f"LogListener {self.name} checking log queue")
                record = self.log_q.get()
                logger.handle(record)  # logs queue entry depend on log_listener_configurer() setup
            except BaseException as exc:
                if type(exc) in (TerminateInterrupt, KeyboardInterrupt, InterruptedError):
                    logger.debug(f"Terminated by signal")
                else:
                    logger.debug(f"Abornmal exit:{exc}", exc_info=True )
                    #import sys, traceback
                    #print('An exception getting messages from log queue:', file=sys.stderr)
                    #traceback.print_exc(file=sys.stderr)
        #logger.debug(f'LogListener main_loop exit')


#TODO Solace logger handler will be derrived this way
#listener_log_configurer would have to be updated to add the handler
class SolaceLogHandler(logging.handlers.QueueHandler):
    def __init__(self, sol_channel, sol_connectivity):
        super().__init__()

    def enqueue(self, record):
        self.queue.send_json(record.__dict__)

    def close(self):
        self.queue.close()




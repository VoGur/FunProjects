import logging.config

#See for the details
#https://packaging.python.org/guides/packaging-namespace-packages/
#https://dev.to/methane/don-t-omit-init-py-3hga

from .config import (
    LOGGING_CONFIG,
)

from .pbqueue import (
    PBqueue,
    PBEvent,
    GrpEventType
)

from .group_mngr import(
    WorkerProc,
    GroupManager
)

from .group_workers import(
    Worker,
    QueueWorker
)

#expose
__all__ = [
    'WorkerProc',
    'GroupManager',
    'PBqueue',
    'PBEvent',
    'GrpEventType',
    'Worker',
    'QueueWorker',
]
logger = logging.getLogger('pb')
logging.config.dictConfig(LOGGING_CONFIG)

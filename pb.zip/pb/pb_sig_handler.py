import logging
import signal
import functools
import pb_config as cfg

MOD_LOG_NAME = "pb.signal"
logger = logging.getLogger(MOD_LOG_NAME)
'''
Termination signals handlers will trigger shutdown event
----------------------------------------------------------

Server process can handle TERM ( Ctrl^C) signal to stop
If server process got stuck, after signal triggered and received N times
exception will be thrown.

Signal hadlers
The signal handlers callbacks set the shutdown_event Event flag the first N times they get called,
and then raise an exception each time they called thereafter:
MAX_NUM_TERM_SIGNAL_CALLED
This allows one to hit control-C twice and be sure to stop code that been hung up waiting
or in a loop, while allowing normal shutdown processing to properly clean up.

To propagate signals:
-------------------------------------------------------------
Signals will be set up separately for each subprocess.
Linux/Unix systems automatically propagate signals to all child processes,
so those subprocesses also need to capture and handle the signals as well.
An advantage to this is that subprocess signal handlers can potentially operate on resources specific to that subprocess.
'''
class TerminateInterrupt(BaseException):
    pass


class ShutdownSignalObject:

    def __init__(self, shutdown_event):
        self.terminate_called = 0
        self.shutdown_event = shutdown_event


def default_signal_handler(signal_object, exception_class, signal_num, current_stack_frame):
    signal_object.terminate_called += 1
    signal_object.shutdown_event.set()
    logger.debug(f"Signal {signal_num} received, signal handler triggered {signal_object.terminate_called} time(s) out of {cfg.MAX_NUM_TERM_SIGNAL_CALLED} attempts")
    if signal_object.terminate_called >= cfg.MAX_NUM_TERM_SIGNAL_CALLED:
        raise exception_class()

#partial used for currying
def init_signal(signal_num, signal_object, exception_class, handler):
    handler = functools.partial(handler, signal_object, exception_class)
    signal.signal(signal_num, handler)

    #System call will be restarted if interrupted by the specified signal signal_num if flag False
    #This is the default behavior in Linux, not available on Windows :
    #line below preserved for now.
    #signal.siginterrupt(signal_num, False)

#https://docs.python.org/3/library/signal.html#example
#only the main thread of the main interpreter is allowed to set a new signal handler
def reg_shutdown_signals(shutdown_event, int_handler = default_signal_handler, term_handler = default_signal_handler):
    signal_object = ShutdownSignalObject(shutdown_event)
    #SIGINT
    init_signal(signal.SIGINT, signal_object, KeyboardInterrupt, int_handler)
    #SIGTERM
    init_signal(signal.SIGTERM, signal_object, TerminateInterrupt, term_handler)
    logger.debug(f"Added SIGINT {signal.SIGINT} and SIGTERM {signal.SIGTERM}")
    return signal_object

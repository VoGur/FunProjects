import logging
import multiprocessing as mp
import multiprocessing.queues as mpq
from queue import Empty, Full
import time
import uuid
from enum import Enum
import pb_config as cfg

MOD_LOG_NAME = "pb.queue"
logger = logging.getLogger(MOD_LOG_NAME)

'''
To make sure Queue objects will be fully cleaned up:
they need to be  emptied of any items that have been left there, closed, and,
importantly, have Queue.join_thread() called so that the associated monitoring thread gets cleaned up
and doesn’t generate a misleading exception message during final Python garbage collection.
Group workers exchange mnessages through the queue
put() and get() timeout if specified allows to specify timeout to wait on the operation if desired
Handle Queue exceptions which could be thrown when put/get
           
Join the background thread join_thread() can only be used after close() has been called.
It blocks until the background thread exits, ensuring that all data in the buffer has been flushed.
Calling .close() and .join_thread() are a recommendation however they are not a must.
close() is called automatically when the Queue is garbage collected
and .join_thread() is called automatically upon process termination.
see discussion here
https://stackoverflow.com/questions/42350933/joining-multiprocessing-queue-takes-a-long-time

'''
class PBqueue(mpq.Queue):

    # mp.Queue is a _method_ that returns an mpq.Queue object.  That object
    # requires a context for proper operation.
    def __init__(self, name, *args, **kwargs):
        ctx = mp.get_context()
        self.name = name
        super().__init__(*args, **kwargs, ctx=ctx)


    def safe_get(self, timeout=cfg.DEFAULT_POLLING_TIMEOUT):
        try:
            if timeout is None:
                return self.get(block=False)
            else:
                return self.get(block=True, timeout=timeout)
        except Empty:
            return None

    def safe_put(self, item, timeout=cfg.DEFAULT_POLLING_TIMEOUT):
        try:
            self.put(item, block=False, timeout=timeout)
            return True
        except Full:
            return False

    def flush(self):
        item = self.safe_get()
        while item:
            yield item
            item = self.safe_get()

    def safe_close(self):
        num_left = sum(1 for __ in self.flush())
        self.close()
        self.name = None
        self.join_thread()
        return num_left

    def is_on(self):
        try:
            #if self.name:
            #    return self.name != None
            #else:
            #    return False
            return True
        except Exception:
            import sys, traceback
            print('An exception :', file=sys.stderr)
            traceback.print_exc(file=sys.stderr)

#Add Events for group processes here
class GrpEventType(Enum):
    FATAL = -1
    STOP = 0
    ERROR = 1
    REQUEST = 2
    RESPONSE = 3
    FORCE_STOP = 4
    START = 5
    RESTART = 6


#Event body Json serialized
class PBEvent:
    def __init__(self, msg_src, msg_type, msg):
        self.tm = time.time()
        self.id = str(uuid.uuid1())
        self.msg_src = msg_src
        self.msg_type = msg_type
        self.body = msg

    def __str__ (self):
        return f"tm:{self.tm} id:{self.id} msg_src:{self.msg_src:10} msg_type:{self.msg_type:10} body:{self.body}"

    #def __str__(self):
    #    return f"{self.tm}-{self.msg_src:10}-{self.msg_type:10}-{self.body}"

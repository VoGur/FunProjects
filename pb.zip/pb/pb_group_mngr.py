import multiprocessing as mp
import sys
import time
import logging
from pb_config import (
    STOP_WAIT_SECS,             #group manager will wait for worker processes when stop
    NUM_TRIES_TO_TERM,          #number of attempts to terminate process
    STARTUP_WAIT_SECS,          #worker process startup timeout
    SHUTDOWN_WAIT_SECS,         #worker process shutdown timeout
)
from pb_sig_handler import (
    reg_shutdown_signals        #set handlers for SIGINT & SIGTERM (CTRL^C)
)
from pb_queue import (
    PBqueue,
    PBEvent,
    GrpEventType
)
#from group_workers import(
#)

from pb_logger import(
    LogListener
)
from pb_worker_proc import WorkerProc

MOD_LOG_NAME = "pb.groupmngr"
logger = logging.getLogger(MOD_LOG_NAME)

'''
"GroupManager" class controls the worker processes and "communication" between them 
"WorkerProc" is a  wrapper/handler which will control the worker lifecycle
You need to specify a class which derrived from "Worker" base class when create "WorkerProc"

Each child process will get a copy of the main process's memory. 
Generally state is shared via communication (pipes/sockets), signals, or shared memory.

When there is only one shared structure, you can easily run into issues with blocking and contention. 
As such structures proliferate, however, the complexity and unexpected interactions multiply, 
potentially leading to deadlocks, and very likely leading to code that is difficult to maintain and test.
 
The better option is to pass messages using multiprocessing.Queue objects. 
Queues should be used to pass all data between subprocesses.

When subprocess notified that it should end  (message or  shutdown_event flag),
subprocess need to clean up after itself by releasing any resources it owns.

When Workers (subprocesses) started by GroupMngr end, they will clean their allocated resources.
The GroupMngr also needs to clean up Queue objects, and other resources 
that it might have control over. Cleaning up the subprocesses
involves making sure that each subprocess gets whatever termination messaging that it might need,
and that the subproceses are actually terminated.
Otherwise, stopping the main process could result in either a hang, or an orphaned zombie subprocess.
Accepted approach involves setting the shutdown flag, waiting for all the processes to stop normally
within some reasonable amount of time, and then terminating any that haven’t stopped yet.
'''

def _sleep_secs(max_sleep, end_time=999999999999999.9):
    # Calculate time left to sleep, no less than 0
    return max(0.0, min(end_time - time.time(), max_sleep))

'''        
"GroupManager" class controls the "WorkerProcesses" and "communications"  between them.
It contains 3 mandatory queues: 
log_queue - to pass log messages from worker to dedicates Logger process
event_queue - to communicate and send control messages within the group
msg_queue - messages arriving from Solace bus

It starts 2 dedicated processes in background
LogListener   - checks for the messages from all Workers present in log_queue and dumps them as specified  
MsgListener   - listens to incoming msgs (Solace or could be anything else) and inserts them into msg_queue  
'''
class GroupManager:

    def __init__(self):
        logger.debug(f"Mngr initialization {self}")
        self.procs = []
        self.queues = []
        #starup event (not used for now)
        self.startup_event = mp.Event()
        #event which trigger shutdown
        self.shutdown_event = mp.Event()
        # queue to exchange events between workers
        self.event_queue = self.create_queue('WrkEvents')
        # Logging facility
        self.log_queue =  self.create_log_queue('Logging')
        #register system signals which we allow to trigger shutdown event
        logger.debug(f"Mngr adding signal handlers to trigger shutdown")
        reg_shutdown_signals(self.shutdown_event)
        #start logger associated with group where all the workers will be redirected
        self.__create_logger_proc()
        #start listening to Solace msg
        #self.__create_msg_rcv_proc()

    def __enter__(self):
        return self

    #Exception hook
    def __exit__(self, exc_type, exc_val, exc_tb):
        logger.debug(f"Mngr exiting {self}")
        if exc_type:
            logger.error(f"Exception thrown: {exc_val}", exc_info=(exc_type, exc_val, exc_tb))

        self._stopped_procs_result = self.stop_procs()
        self._stopped_queues_result = self.stop_queues()
        #Don't eat exceptions that reach here.
        return not exc_type

    #each dedicated worker gets it's dedicated msg queue
    def create_worker_proc(self, name, worker_class, *args):
        msg_queue = self.create_queue(name)
        proc = WorkerProc(name, worker_class,  self.startup_event, self.shutdown_event, self.log_queue, self.event_queue, msg_queue, *args)
        logger.debug(f"Mngr started {name} {proc.proc.pid}")
        self.procs.append(proc)
        return proc, msg_queue

    #each group has it's dedicated shared logger process
    def __create_logger_proc(self, *args):
        proc = WorkerProc('LogListener', LogListener , self.startup_event, self.shutdown_event, self.log_queue, self.event_queue, None, *args)
        logger.debug(f"Mngr started LogListener {proc.proc.pid}")
        self.procs.append(proc)
        return proc


    def create_queue(self, name, *args, **kwargs):
        q = PBqueue(name, *args, **kwargs)
        logger.debug(f"Mngr created queue for {q.name}")
        self.queues.append(q)
        return q

    def create_log_queue(self, name, *args, **kwargs):
        q = PBqueue(name, *args, **kwargs)
        logger.debug(f"Mngr created queue for {q.name}")
        self.queues.append(q)
        return q

    def stop_procs(self):
        logger.debug(f"Mngr attempts to stop all associated processes by triggerring shutdown event")
        stop_event = PBEvent("stop_procs", GrpEventType.STOP, "END")
        logger.debug(f"STOP event msg {stop_event} added to Event queue and shutdown triggered")
        self.event_queue.safe_put(stop_event)
        self.shutdown_event.set()
        end_time = time.time() + STOP_WAIT_SECS
        num_terminated = 0
        num_failed = 0

        #Wait up to STOP_WAIT_SECS for all processes to complete
        for proc in self.procs:
            join_secs = _sleep_secs(STOP_WAIT_SECS, end_time)
            proc.proc.join(join_secs)


        #Terminate any procs that have not yet exited and clear proc list
        still_running = []
        while self.procs:
            proc = self.procs.pop()

            if proc.proc.is_alive():
                logger.debug(f"Will attempt to terminate worker {proc.proc.pid} {proc.proc}")
                if proc.terminate():
                    num_terminated += 1
                else:
                    still_running.append(proc)

            else:
                logger.debug(f"Process: {proc.proc.pid}, Name: {proc.name}, Status: {proc.proc}, Exit code: {proc.proc.exitcode}")
                exitcode = proc.proc.exitcode
                if exitcode:
                    num_failed += 1

        #Preserve and log details of processes which are still running
        self.procs = still_running
        if(self.procs):
            logger.debug(f"Mngr still has runing processes:")
            for proc in self.procs:
                logger.debug(f"Worker {proc.proc.pid} Status {proc.proc} Exit code {proc.proc.exitcode}")

        return num_failed, num_terminated

    def stop_queues(self):
        num_items_left = 0
        logger.debug(f"Mngr attempts to close all associated queues")
        #Close all Grp associated queues
        for q in self.queues:
            num_items_left += sum(1 for __ in q.flush())
            q.close()

        #Wait for all queue threads to stop and clear proc list
        while self.queues:
            q = self.queues.pop(0)
            q.join_thread()
            logger.debug(f"Closing {q} {q.name}")

        return num_items_left





import time
import sys

import logging
import socket
import random # for testing only
from pb_queue import (
    PBqueue,
    PBEvent,
    GrpEventType
)
from pb_sig_handler import (
    reg_shutdown_signals,        #set handlers for SIGINT & SIGTERM (CTRL^C)
    TerminateInterrupt
)
import pb_logger as pblog

MOD_LOG_NAME = "pb.wrkr"
logger = logging.getLogger(MOD_LOG_NAME)

'''
Worker is a subprocess started by WrkProc in the group
When subprocess notified that it should end  (message or  shutdown_event flag),
subprocess need to clean up after itself by releasing any resources it owns.
'''

def sleep_secs(max_sleep, end_time=99999999999.9):
    #Calculate time left to sleep, no less than 0
    return max(0.0, min(end_time - time.time(), max_sleep))
'''
Each worer process has access to event queue and log queue and has to have mandatory parameters:
worker name
startup_event
shutdown_event
3 mandatory queues: 
log_queue - to pass log messages from worker to dedicates Logger process
event_queue - to communicate and send control messages within the group
msg_queue - messages arriving from Solace bus and dispatched to the process
Optional arguments passed as args 
'''
class Worker:
    def __init__(self, name, startup_event, shutdown_event, log_q, event_q, msg_q, *args):
        self.name = name
        self.startup_event = startup_event
        self.shutdown_event = shutdown_event
        self.log_q = log_q
        self.event_q = event_q
        self.msg_q = msg_q
        self.terminate_called = 0
        self.init_args(args)
        #listener worker will be listening to the log queue, all the other w will be writing to it
        if name == 'LogListener':
            logger = pblog.listener_log_configurer(MOD_LOG_NAME)
            logger.info(f'Setting logger for {name}')
        else:
            logger = pblog.worker_log_configurer(log_q, MOD_LOG_NAME)
            logger.info(f'Setting logger for the worker {name}')

    def init_args(self, args):
        if args:
            raise ValueError(f"Unexpected arguments init_args: {args}")

    #set up system signals which will trigger shutdown event
    def init_signals(self):
        #logger.debug(f"Signals set")
        signal_object = reg_shutdown_signals(self.shutdown_event)
        return signal_object

    #Looping until get shutdown
    def main_loop(self):
        logger.debug(f"Start main_loop")
        while not self.shutdown_event.is_set():
            self.main_func()

    def startup(self):
        pass

    def shutdown(self):
        pass

    def main_func(self, *args):
        logger.debug(f"Start main_func")
        raise NotImplementedError(f"{self.__class__.__name__} main_func is not implemented")

    def run(self):
        #logger.debug(f"Started run")
        self.init_signals()
        try:
            self.startup()
            #the event will be checked as a sign that the process is running OK
            self.startup_event.set()
            self.main_loop()
            self.event_q.safe_put(PBEvent(self.name, "SHUTDOWN", "Normal"))
            return 0
        except BaseException as exc:
            import sys, traceback
            if type(exc) in (TerminateInterrupt, KeyboardInterrupt, InterruptedError):
                logger.debug(f"Terminated by signal {exc}", exc_info=True)
                self.event_q.safe_put(PBEvent(self.name, "FATAL", f"{exc}"))
                sys.exit(1)
            else:
                #print('An exception getting messages from log queue:', file=sys.stderr)
                #traceback.print_exc(file=sys.stderr)
                logger.error(f"Terminated by signal {exc}", exc_info=True)
                self.event_q.safe_put(PBEvent(self.name, "FATAL", f"{exc}"))
                sys.exit(1)
            # -- Catch ALL exceptions, even Terminate and Keyboard interrupt
            #logger.error( f"Wrkr abnormal shutdown: {exc}", exc_info=True)


            # -- TODO: call raise if in some sort of interactive mode
            #if type(exc) in (TerminateInterrupt, KeyboardInterrupt):
            #    sys.exit(1)
            #else:
            #    sys.exit(2)
        finally:
            self.shutdown()

#-------------- Extended Worker classes override at least main_func() --------------------


'''

class StatusWorker(TimerWorker):

    def startup(self):
        self.last_status = None

    def get_status(self):
        return "OKAY" if random.randrange(10) else "NOT-OKAY"

    def main_func(self):
        # -- Do the things to check current status, only send the status message
        # if status has changed
        curr_status = self.get_status()
        if curr_status != self.last_status:
            self.event_q.put(PBEvent(self.name, "STATUS", curr_status))
            self.last_status = curr_status


#Control messages received from Solace
#Test incoming Solace message functionality which will be handlled by Solace receiver callback
class SolaceMsgsDispatcher(TimerWorker):

    def startup(self):
        self.last_status = None

    def get_status(self):
        return "OKAY" if random.randrange(10) else "NOT-OKAY"

    def main_func(self):
        # -- Do the things to check current status, only send the status message
        # if status has changed
       while not self.shutdown_event.is_set():
            logger.log(logging.DEBUG, f"Received from Solace")
            self.event_q.put(PBEvent("LISTEN", "REQUEST", "test"))

            logger.log(logging.DEBUG, f"QueueWorker.main_loop received '{item}' message")
'''




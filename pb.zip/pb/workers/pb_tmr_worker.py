from pb_worker import (
    Worker,
    sleep_secs)

import logging
import time
from pb_queue import (
    PBEvent
)

MOD_LOG_NAME = "pb.wrkr.tmrwrkr"
logger = logging.getLogger(MOD_LOG_NAME)

#Worker which periodically wakes up and does something
class TimerWorker(Worker):
    INTERVAL_SECS = 10
    MAX_SLEEP_SECS = 0.02

    def main_loop(self):
        logger.log(logging.DEBUG, "Entering TimerProcWorker.main_loop")
        next_time = time.time() + self.INTERVAL_SECS
        while not self.shutdown_event.is_set():
            sleep_tm = sleep_secs(self.MAX_SLEEP_SECS, next_time)
            time.sleep(sleep_tm)
            if time.time() > next_time:
                logger.log(logging.DEBUG, f"TimerProcWorker.main_loop : calling main_func")
                self.main_func()
                next_time = time.time() + self.INTERVAL_SECS




from pb_worker import Worker
import logging
import sys
from pb_queue import (
    PBEvent
)
from pb_sig_handler import (
    reg_shutdown_signals,        #set handlers for SIGINT & SIGTERM (CTRL^C)
    TerminateInterrupt
)
MOD_LOG_NAME = "pb.wrkr.queuewrkr"
logger = logging.getLogger(MOD_LOG_NAME)


#Worker with main loop checking for messages from the queue
class QueueWorker(Worker):

    def init_args(self, args):
        logger.log(logging.DEBUG, f"QueueWorker init_args : {args}")

    def main_loop(self):
        logger.debug(f"QueueWorker Name: {self.name} main_loop start")
        while not self.shutdown_event.is_set():
            try:
                item = self.event_q.safe_get()

            except BaseException as exc:
                if type(exc) in (TerminateInterrupt, KeyboardInterrupt, InterruptedError):
                    logger.debug(f"Terminated by signal {exc}", exc_info=True)
                else:
                    logger.error(f"Abnormal exit: {exc}", exc_info=True)
            finally:
                self.shutdown()



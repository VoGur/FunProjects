from pb_tmr_worker import TimerWorker
import random
import logging
from pb_queue import (
    PBEvent
)
MOD_LOG_NAME = "pb.wrkr.misc"
logger = logging.getLogger(MOD_LOG_NAME)

#Control messages received from Solace
#Test incoming Solace message functionality which will be handlled by Solace receiver callback
class SolaceMsgsDispatcher(TimerWorker):

    def startup(self):
        self.last_status = None

    def get_status(self):
        return "OKAY" if random.randrange(10) else "NOT-OKAY"

    def main_func(self):
        # -- Do the things to check current status, only send the status message
        # if status has changed
       while not self.shutdown_event.is_set():
            logger.log(logging.DEBUG, f"Received from Solace")
            self.event_q.put(PBEvent("LISTEN", "REQUEST", "test"))

            logger.log(logging.DEBUG, f"QueueWorker.main_loop received '{item}' message")
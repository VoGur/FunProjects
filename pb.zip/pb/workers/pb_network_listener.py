from pb_worker import Worker
import logging
import socket
from pb_queue import (
    PBEvent
)
MOD_LOG_NAME = "pb.wrkr.netwrkr"
logger = logging.getLogger(MOD_LOG_NAME)

#Worker listens to TCP/IP hardcoded 9876 port
class NetworkListenerWorker(Worker):
    PORT = 9876
    HOST = 'localhost'
    SOCKET_TIMEOUT = 5.0

    def init_args(self, args):
        self.reply_q, = args

    def startup(self):
        logger.debug(f"Worker startup {self.HOST}:{self.PORT}")
        #set socket connection on start up
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind((self.HOST, self.PORT))
        self.socket.settimeout(self.SOCKET_TIMEOUT)
        self.socket.listen(1)
        logger.debug(f"Worker start listening...")

    def shutdown(self):
        #Called when worker process is shutting down
        logger.debug(f"Worker shutdown {self.HOST}:{self.PORT}")
        self.socket.close()


    #def main_loop(self):
    #    logger.debug(f"NetworkListenerWorker: {self.name} main_loop start")

    #To handle request and reply
    def main_func(self):

        try:
            (clientsocket, address) = self.socket.accept()
        except socket.timeout:
                logger.debug(f"No messages" )
                return
        except BaseException as exc:
                logger.debug(f"Exception:{exc}", exc_info=True)
                return

        logger.info(f"Accepted connection from {clientsocket.getpeername()}")
        try:
            clientsocket.settimeout(self.SOCKET_TIMEOUT)
            buffer = clientsocket.recv(1500).decode()
            logger.debug(f"Received : {buffer}")
            adtn = ""
            if("REQUEST" in buffer):
                self.event_q.put(PBEvent("LISTENER", "REQUEST", buffer))
                adtn = "'REQUEST'"
            elif("END" in buffer):
                self.event_q.put(PBEvent("LISTENER", "END", buffer))
                adtn = "'END'"
            elif ("STATS" in buffer):
                self.event_q.put(PBEvent("LISTENER", "STATS", buffer))
                adtn = "'STATS'"
            else:
                adtn = "'UNKNOWN COMMAND'"

            reply = "SRV recognized " + adtn  + " , reply with the same msg: " + f"'{buffer}'"
            logger.debug(f"Reply: {reply}")
            clientsocket.send(reply.encode("utf-8"))
        finally:
            clientsocket.close()
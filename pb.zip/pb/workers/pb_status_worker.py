from pb_worker import Worker
import logging
import random
from pb_queue import (
    PBEvent
)
MOD_LOG_NAME = "pb.wrkr.statwrkr"
logger = logging.getLogger(MOD_LOG_NAME)

class StatusWorker(Worker):

    def startup(self):
        self.last_status = None

    def get_status(self):
        return "OKAY" if random.randrange(10) else "NOT-OKAY"

    def main_func(self):
        # -- Do the things to check current status, only send the status message
        # if status has changed
        curr_status = self.get_status()
        if curr_status != self.last_status:
            self.event_q.put(PBEvent(self.name, "STATUS", curr_status))
            self.last_status = curr_status